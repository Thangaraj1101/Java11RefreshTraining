package com.hlag.aricargosystem.main;

public class Shipment {

	private String destination;

	private String shipmentType;

	private String shipmentDate;

	private String trackingNumber;

	private boolean insurance;

	private boolean giftWrap;

	private Shipment(ShipmentBuilder shipmentBuilder) {
		this.destination = shipmentBuilder.destination;
		this.shipmentType = shipmentBuilder.shipmentType;
		this.shipmentDate = shipmentBuilder.shipmentDate;
		this.trackingNumber = shipmentBuilder.trackingNumber;
		this.insurance = shipmentBuilder.insurance;
		this.giftWrap = shipmentBuilder.giftWrap;
	}

	static class ShipmentBuilder {

		private String destination;

		private String shipmentType;

		private String shipmentDate;

		private String trackingNumber;

		private boolean insurance;

		private boolean giftWrap;

		public ShipmentBuilder(String destination, String shipmentType, String shipmentDate) {
			this.destination = destination;
			this.shipmentType = shipmentType;
			this.shipmentDate = shipmentDate;
		}

		public ShipmentBuilder setTrackingNumber(String trackingNumber) {
			this.trackingNumber = trackingNumber;
			return this;
		}

		public ShipmentBuilder setInsurance(boolean insurance) {
			this.insurance = insurance;
			return this;
		}

		public ShipmentBuilder setGiftWrap(boolean giftWrap) {
			this.giftWrap = giftWrap;
			return this;
		}

		public Shipment build() {
			return new Shipment(this);
		}

	}

	@Override
	public String toString() {
		return "Shipment [destination=" + destination + ", shipmentType=" + shipmentType + ", shipmentDate=" + shipmentDate
				+ ", trackingNumber=" + trackingNumber + ", insurance=" + insurance + ", giftWrap=" + giftWrap + "]";
	}

}
