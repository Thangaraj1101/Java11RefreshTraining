package com.hlag.aricargosystem.service;

public class Cargo implements Trackable {

	private String cargoId;

	private String description;

	protected int weight;


	public Cargo(String cargoId,String description, int weight) {
		this.cargoId = cargoId;
		this.description = description;
		this.weight = setWeight(weight);
	}

	public String getCargoId() {
		return cargoId;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDescription() {
		return description;
	}

	public int setWeight(int weight) {
		if (weight <= 0) {
			System.out.println("Weight Must be greater than Zero");
		}
		return weight;
	}

	public void displayCargoDetails() {
		System.out.println("CargoId :" + cargoId + " " + "Description :" + description + " " + "Weight :" + weight);
	}

	@Override
	public void trackCargo() {
	}



}
