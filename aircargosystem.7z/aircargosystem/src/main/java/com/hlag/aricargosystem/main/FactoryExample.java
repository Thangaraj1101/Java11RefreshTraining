package com.hlag.aricargosystem.main;

// Step 1: Define the Shipment interface
interface ShipmentFactory {

	void deliver();
}

// Step 2: Create concrete classes for different shipment types
class AirShipment implements ShipmentFactory {

	@Override
	public void deliver() {
		System.out.println("Delivering by air.");
	}
}

class SeaShipment implements ShipmentFactory {

	@Override
	public void deliver() {
		System.out.println("Delivering by sea.");
	}
}

class LandShipment implements ShipmentFactory {

	@Override
	public void deliver() {
		System.out.println("Delivering by land.");
	}
}

// Step 3: Create a ShipmentFactory class
class ShipmentFactoryImpl {

	// Factory method to create Shipment objects
	public static ShipmentFactory createShipment(String shipmentType) {
		switch (shipmentType.toLowerCase()) {
			case "air":
				return new AirShipment();
			case "sea":
				return new SeaShipment();
			case "land":
				return new LandShipment();
			default:
				throw new IllegalArgumentException("Invalid shipment type: " + shipmentType);
		}
	}


}
