package com.hlag.aricargosystem.service;


public interface Trackable {

	void trackCargo();

	public static double calculateShippingCost(double weight) {
		return weight * 2.5;
	}

	public static double calculateShippingCost(double weight, double distance) {
		return weight * distance * 0.05;
	}

}
