package com.hlag.aricargosystem.service;


public abstract class CargoItem {

	protected String cargoId;

	protected CargoItem(String cargoId) {
		this.cargoId = cargoId;
	}

	// Abstract method
	public abstract double calculateShippingCost();

}
