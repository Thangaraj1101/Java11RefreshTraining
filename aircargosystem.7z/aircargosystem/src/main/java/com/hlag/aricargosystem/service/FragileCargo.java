package com.hlag.aricargosystem.service;


public class FragileCargo extends Cargo {

	private String handlingInstructions;


	public FragileCargo(String cargoId, String description, int weight, String instructions) {
		super(cargoId, description, weight);
		this.handlingInstructions = displayHandlingInstructions(instructions);
	}

	public String displayHandlingInstructions(String instructions) {
		switch (instructions) {
			case "Fragile":
				return "Handle With Care";
			case "hazdours":
				return "Follow safety protocols.";
			default:
				return "Regular cargo.";
		}
	}

	@Override
	public void displayCargoDetails() {
		super.displayCargoDetails();
		System.out.println("Handling Instruction : " + handlingInstructions);
	}

	public static void main(String[] args) {
		Cargo cargo = new FragileCargo("C002", "Glassware", 0, "Handle with care.");
		cargo.displayCargoDetails();
	}


}
