package com.hlag.javahandson.funtionalinterface;

import java.util.List;

@FunctionalInterface
public interface Filter {

	List<Integer> apply(int number);

}
