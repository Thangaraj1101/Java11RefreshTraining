package com.hlag.javahandson.funtionalinterface;


public interface Factorial {

}
