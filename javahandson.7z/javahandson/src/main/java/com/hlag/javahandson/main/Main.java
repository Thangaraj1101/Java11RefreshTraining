package com.hlag.javahandson.main;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import com.hlag.javahandson.funtionalinterface.CheckNumber;
import com.hlag.javahandson.funtionalinterface.Greeter;
import com.hlag.javahandson.funtionalinterface.ListTransformer;
import com.hlag.javahandson.funtionalinterface.Processor;

public class Main {

	public static void main(String[] args) {

		// Functional interface

		Greeter greeter = name -> System.out.println("Hello," + " " + name);
		greeter.greet("Alice");

		// check odd or even

		CheckNumber checkNumberEvenOrOdd = number -> {
			if (number % 2 == 0) {
				System.out.println("The given number is Even " + number);
			} else {
				System.out.println("The given number is Odd " + number);
			}
		};
		checkNumberEvenOrOdd.checkNumberEvenOrOdd(2);
		checkNumberEvenOrOdd.checkNumberEvenOrOdd(3);

		// chain the number

		Processor addTen = number -> number + 10;
		Processor multiplyByTwo = number -> number * 2;
		Processor subtractFive = number -> number - 5;

		Processor chainProcess = number -> subtractFive.process(multiplyByTwo.process(addTen.process(number)));
		System.out.println(chainProcess.process(5));

		// Sort the list alphabetically.

		List<String> listName = Arrays.asList("ORANGE", "MANGO", "APPLE");

		ListTransformer listTransformer = listString -> listString.stream().sorted().collect(Collectors.toList());
		System.out.println(listTransformer.transform(listName));

		// convert all list into lower case
		ListTransformer listTransformerToLowerCase = listString -> listString.stream()
				.map(String::toLowerCase)
				.collect(Collectors.toList());
		System.out.println(listTransformerToLowerCase.transform(listName));

	}
}
