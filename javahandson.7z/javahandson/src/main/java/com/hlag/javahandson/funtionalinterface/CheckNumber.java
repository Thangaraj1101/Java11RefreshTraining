package com.hlag.javahandson.funtionalinterface;

@FunctionalInterface
public interface CheckNumber {

	void checkNumberEvenOrOdd(int number);
}
