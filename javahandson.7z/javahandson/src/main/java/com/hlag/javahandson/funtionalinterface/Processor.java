package com.hlag.javahandson.funtionalinterface;

@FunctionalInterface
public interface Processor {

	int process(int number);

}
