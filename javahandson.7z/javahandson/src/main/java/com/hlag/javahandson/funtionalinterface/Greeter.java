package com.hlag.javahandson.funtionalinterface;


@FunctionalInterface
public interface Greeter {

	void greet(String name);

}
