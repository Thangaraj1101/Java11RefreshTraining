package com.hlag.shipmentmanagementsystem.service;

import com.hlag.shipmentmanagementsystem.entity.Shipment;

public interface ShipmentService {

	public Shipment trackingStatus(String trackingNumber);

	public void updateShipmentStatus(String shipmentId, String status);

}
