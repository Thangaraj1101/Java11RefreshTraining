package com.hlag.shipmentmanagementsystem.service;

import com.hlag.shipmentmanagementsystem.entity.Shipment;

public class ShipmentServiceImpl implements ShipmentService {

	private static ShipmentServiceImpl shipmentServiceImpl;

	public static ShipmentServiceImpl getInstance() {
		if (shipmentServiceImpl == null) {
			shipmentServiceImpl = new ShipmentServiceImpl();
		}
		return shipmentServiceImpl;
	}

	@Override
	public Shipment trackingStatus(String trackingNumber) {
		return null;
	}

	@Override
	public void updateShipmentStatus(String shipmentId, String status) {
		// TODO Auto-generated method stub

	}

}
