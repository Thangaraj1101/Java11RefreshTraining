package com.hlag.shipmentmanagementsystem.service;

import java.util.Optional;

import com.hlag.shipmentmanagementsystem.entity.User;

public class UserServiceImpl implements UserService {

	private static UserServiceImpl userServiceImpl;

	public static UserServiceImpl getInstance() {
		if (userServiceImpl == null) {
			userServiceImpl = new UserServiceImpl();
		}
		return userServiceImpl;
	}

	@Override
	public User createUser(User user) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<User> getUserById(String id) {
		// TODO Auto-generated method stub
		return Optional.empty();
	}

	@Override
	public void updateUser(String id, User user) {
		// TODO Auto-generated method stub

	}

}
