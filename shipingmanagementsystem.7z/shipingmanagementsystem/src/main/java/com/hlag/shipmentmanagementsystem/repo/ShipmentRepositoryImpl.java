package com.hlag.shipmentmanagementsystem.repo;

import com.hlag.shipmentmanagementsystem.entity.Shipment;

public class ShipmentRepositoryImpl implements ShipmentRepository {

	private static ShipmentRepositoryImpl shipmentRepositoryImpl;

	public static ShipmentRepositoryImpl getInstance() {
		if (shipmentRepositoryImpl == null) {
			shipmentRepositoryImpl = new ShipmentRepositoryImpl();
		}
		return shipmentRepositoryImpl;
	}

	@Override
	public Shipment trackingStatus(String trackingNumber) {
		return null;
	}

	@Override
	public void updateShipmentStatus(String shipmentId, String status) {

	}

}
