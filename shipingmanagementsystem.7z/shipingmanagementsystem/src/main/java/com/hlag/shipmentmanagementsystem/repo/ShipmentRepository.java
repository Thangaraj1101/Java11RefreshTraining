package com.hlag.shipmentmanagementsystem.repo;

import com.hlag.shipmentmanagementsystem.entity.Shipment;

public interface ShipmentRepository {

	public Shipment trackingStatus(String trackingNumber);

	public void updateShipmentStatus(String shipmentId, String status);

}
