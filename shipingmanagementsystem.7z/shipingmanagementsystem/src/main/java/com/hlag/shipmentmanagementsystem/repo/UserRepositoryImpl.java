package com.hlag.shipmentmanagementsystem.repo;

import java.util.Objects;
import java.util.Optional;

import com.hlag.shipmentmanagementsystem.entity.User;

public class UserRepositoryImpl implements UserRepository {

	private static UserRepositoryImpl userRepositoryImpl;

	public static UserRepositoryImpl getInstance() {

		synchronized (UserRepositoryImpl.class) {
			if (userRepositoryImpl == null) {
				userRepositoryImpl = new UserRepositoryImpl();
			}
		}
			return userRepositoryImpl;
	}

	@Override
	public User createUser(User user) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<User> getUserById(String id) {
		// TODO Auto-generated method stub
		return Optional.empty();
	}

	@Override
	public void updateUser(String id, User user) {
		// TODO Auto-generated method stub

	}

	@Override
	public int hashCode() {
		return Objects.hash(userRepositoryImpl);
	}

}
