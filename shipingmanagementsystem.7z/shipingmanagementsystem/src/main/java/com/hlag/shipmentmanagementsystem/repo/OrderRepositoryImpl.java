package com.hlag.shipmentmanagementsystem.repo;

import java.util.Optional;

import com.hlag.shipmentmanagementsystem.entity.Order;

public class OrderRepositoryImpl implements OrderRepository {

	private static OrderRepositoryImpl orderRepositoryImpl;

	public static OrderRepositoryImpl getInstance() {
		if (orderRepositoryImpl == null) {
			orderRepositoryImpl = new OrderRepositoryImpl();
		}
		return orderRepositoryImpl;
	}

	@Override
	public Order createOrder(Order order) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<Order> getOrdersById(String orderId) {
		// TODO Auto-generated method stub
		return Optional.empty();
	}

	@Override
	public void deleteOrder(String orderId) {
		// TODO Auto-generated method stub

	}

	@Override
	public void updateOrder(String orderId, Order order) {
		// TODO Auto-generated method stub

	}

}
