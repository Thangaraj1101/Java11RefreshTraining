package com.hlag.shipmentmanagementsystem.entity;

import java.util.UUID;

public class Order {

	private UUID orderId;

	private String customer;

	private String destination;

	private String status;

	private double weight;

	public Order(UUID orderId, String customer, String destination, String status, double weight) {
		this.orderId = orderId;
		this.customer = customer;
		this.destination = destination;
		this.status = status;
		this.weight = weight;
	}

	public UUID getOrderId() {
		return orderId;
	}

	public String getCustomer() {
		return customer;
	}

	public String getDestination() {
		return destination;
	}

	public String getStatus() {
		return status;
	}

	public double getWeight() {
		return weight;
	}

	public void setOrderId(UUID orderId) {
		this.orderId = orderId;
	}

	public void setCustomer(String customer) {
		this.customer = customer;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", customer=" + customer + ", destination=" + destination + ", status="
				+ status + ", weight=" + weight + "]";
	}

}
