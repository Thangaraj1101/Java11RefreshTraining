package com.hlag.shipmentmanagementsystem.main;

import com.hlag.shipmentmanagementsystem.repo.UserRepository;
import com.hlag.shipmentmanagementsystem.repo.UserRepositoryImpl;

public class AppMain {

	public static void main(String[] args) {

		Runnable runnable = () -> {
			UserRepository userRepository = UserRepositoryImpl.getInstance();
			System.out.println(userRepository.hashCode());
		};

		Thread thread = new Thread(runnable);
		thread.start();

		// Thread thread1 = new Thread(runnable);
		// thread1.start();
		//
		// Thread thread2 = new Thread(runnable);
		// thread2.start();
	}

}
