package com.hlag.shipmentmanagementsystem.service;

import java.util.Optional;

import com.hlag.shipmentmanagementsystem.entity.Order;

public interface OrderService {

	public Order createOrder(Order order);

	public Optional<Order> getOrdersById(String orderId);

	public void deleteOrder(String orderId);

	public void updateOrder(String orderId, Order order);
}
