package com.hlag.shipmentmanagementsystem.repo;

import java.util.Optional;

import com.hlag.shipmentmanagementsystem.entity.User;

public interface UserRepository {

	public User createUser(User user);

	public Optional<User> getUserById(String id);

	public void updateUser(String id, User user);

}
