package com.hlag.shipmentmanagementsystem.service;

import java.util.Optional;

import com.hlag.shipmentmanagementsystem.entity.User;

public interface UserService {

	public User createUser(User user);

	public Optional<User> getUserById(String id);

	public void updateUser(String id, User user);

}
