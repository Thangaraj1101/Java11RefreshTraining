package com.hlag.shipmentmanagementsystem.service;

import java.util.Optional;

import com.hlag.shipmentmanagementsystem.entity.Order;

public class OrderServiceImpl implements OrderService {

	private static OrderServiceImpl orderServiceImpl;

	public static OrderServiceImpl getInstance() {
		if (orderServiceImpl == null) {
			orderServiceImpl = new OrderServiceImpl();
		}
		return orderServiceImpl;
	}

	@Override
	public Order createOrder(Order order) {
		return null;
	}

	@Override
	public Optional<Order> getOrdersById(String orderId) {
		return Optional.empty();
	}

	@Override
	public void deleteOrder(String orderId) {
		// TODO document why this method is empty
	}

	@Override
	public void updateOrder(String orderId, Order order) {
		// TODO document why this method is empty
	}

}
