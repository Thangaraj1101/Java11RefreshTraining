package com.hlag.shipmentmanagementsystem.entity;

import java.util.UUID;

public class Shipment {

	private UUID shipmentId;

	private String trackingNumber;

	private String order;

	private String assignedDriver;

	private String shipmentStatus;

	public Shipment(UUID shipmentId, String trackingNumber, String order, String assignedDriver, String shipmentStatus) {
		this.shipmentId = shipmentId;
		this.trackingNumber = trackingNumber;
		this.order = order;
		this.assignedDriver = assignedDriver;
		this.shipmentStatus = shipmentStatus;
	}

	public UUID getShipmentId() {
		return shipmentId;
	}

	public String getTrackingNumber() {
		return trackingNumber;
	}

	public String getOrder() {
		return order;
	}

	public String getAssignedDriver() {
		return assignedDriver;
	}

	public void setShipmentId(UUID shipmentId) {
		this.shipmentId = shipmentId;
	}

	public void setTrackingNumber(String trackingNumber) {
		this.trackingNumber = trackingNumber;
	}

	public void setOrder(String order) {
		this.order = order;
	}

	public void setAssignedDriver(String assignedDriver) {
		this.assignedDriver = assignedDriver;
	}

	public String getShipmentStatus() {
		return shipmentStatus;
	}

	public void setShipmentStatus(String shipmentStatus) {
		this.shipmentStatus = shipmentStatus;
	}

	@Override
	public String toString() {
		return "Shipment [shipmentId=" + shipmentId + ", trackingNumber=" + trackingNumber + ", order=" + order
				+ ", assignedDriver=" + assignedDriver + ", shipmentStatus=" + shipmentStatus + "]";
	}

}
