package com.hlag.testing.employee;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class CustomCollector {

	public static void main(String[] args) {

		List<Product> products = Arrays.asList(
				new Product("Laptop", 10),
				new Product("Mouse", 20),
				new Product("Keyboard", 20),
				new Product("Monitor", 20),
				new Product("Charger", 20));

		// Custom Collector
		Map<String, Double> priceRangeTotals = products.stream().collect(Collectors.groupingBy(product -> {
			if (product.getPrice() < 50) {
				return "<50";
			} else if (product.getPrice() < 100) {
				return "50-100";
			} else {
				return ">100";
			}
		}, Collector.of(() -> new double[1], (t, u) -> t[0] += u.getPrice(), (t, u) -> {
			t[0] += u[0];
			return t;
		}, t -> t[0])));

		priceRangeTotals.forEach((k, v) -> System.out.println(k + " " + v));
		// Runnable runnable = () ->
		// IntStream.range(0, 8).forEach(e -> {
		// try {
		// Thread.sleep(1000);
		// System.out.println(Thread.currentThread().getName());
		// } catch (InterruptedException u) {
		// u.printStackTrace();
		// }
		// });
		// Thread thread = new Thread(runnable);
		// thread.setPriority(Thread.MIN_PRIORITY);
		// thread.start();
		// System.out.println("=============>thread 1");
		// Thread thread2 = new Thread(runnable);
		// thread2.setPriority(Thread.MAX_PRIORITY);
		// thread2.start();
		// System.out.println("==============>thread 2");
		// Thread thread3 = new Thread(runnable);
		// thread3.setPriority(Thread.NORM_PRIORITY);
		// thread3.start();
		// System.out.println("================>thread 3");


	}

}
