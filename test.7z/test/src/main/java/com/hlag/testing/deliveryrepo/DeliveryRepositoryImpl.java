package com.hlag.testing.deliveryrepo;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import com.hlag.testing.delivery.Delivery;
import com.hlag.testing.exception.DataNotFoundException;

public class DeliveryRepositoryImpl implements DeliveryRepository {

	private static DeliveryRepositoryImpl deliveryRepositoryImpl;

	public static DeliveryRepositoryImpl getInstance() {
		if (deliveryRepositoryImpl == null) {
			deliveryRepositoryImpl = new DeliveryRepositoryImpl();
		}
		return deliveryRepositoryImpl;
	}

	private List<Delivery> deliveries = new ArrayList<>();

	// Save a new delivery
	@Override
	public void save(Delivery delivery) {
		// deliveries.add(delivery);
	}

	// Find a delivery by its ID
	@Override
	public Optional<Delivery> findById(String deliveryId) {
		return deliveries.stream().filter(delivery -> delivery.getDeliveryId().equals(deliveryId)).findFirst();
	}

	// Get all deliveries
	@Override
	public List<Delivery> findAll() {
		return new ArrayList<>(deliveries);
	}

	// Update an existing delivery
	@Override
	public void update(Delivery delivery) {
		Optional<Delivery> existingDelivery = findById(delivery.getDeliveryId());
		if (existingDelivery.isPresent()) {
			deliveries.remove(existingDelivery.get());
			deliveries.add(delivery);
		}
	}

	// Delete a delivery by its ID
	@Override
	public void deleteById(String deliveryId) {
		deliveries.removeIf(delivery -> delivery.getDeliveryId().equals(deliveryId));
	}

	// Get deliveries that are completed
	@Override
	public List<Delivery> findCompletedDeliveries() {
		return deliveries.stream().filter(Delivery::isCompleted).collect(Collectors.toList());
	}

	@Override
	public List<Delivery> findFirstFiftyThresolds() {
		return deliveries.stream().filter(delivery -> delivery.getRevenue() > 50).collect(Collectors.toList());
	}

	public List<Delivery> markDeliveryAsCompleted(Delivery delivery) {
		return deliveries.stream().map(e -> {
			if (e.getDeliveryId().equals(delivery.getDeliveryId())) {
				delivery.setCompleted(true);
				deliveries.add(delivery);
			}
			return delivery;
		}).collect(Collectors.toList());
	}

	public List<Delivery> markDeliveryAsCompleted1(Delivery delivery) {
		return deliveries.stream().filter(e -> e.getDeliveryId().equals(delivery.getDeliveryId())).map(e -> {
			e.setCompleted(true);
			return e;
		}).collect(Collectors.toList());
	}

	public void removeDeliveredDetails() {
		deliveries.removeIf(e -> e.isCompleted());
	}

	@Override
	public double calculateTotalRevenue() {
		return deliveries.stream().mapToDouble(e -> e.getRevenue()).sum();
	}

	@Override
	public double averageTime() throws DataNotFoundException {
		return deliveries.stream()
				.mapToDouble(e -> e.getDeliveryTimeInHours())
				.average()
				.orElseThrow(() -> new DataNotFoundException("The provided data is not present"));
	}

	public List<Delivery> findTopPerfomance() {
		return deliveries.stream()
				.filter(Delivery::isCompleted)
				.sorted(
						(a, b) -> Double.compare(a.getDeliveryTimeInHours(), b.getDeliveryTimeInHours()))
				.limit(5)
				.collect(Collectors.toList());
	}
}
