package com.hlag.testing.sample;

import java.util.UUID;
import java.util.regex.Pattern;

import com.hlag.testing.exception.InvalidNameException;

public class User {

	private static User user;

	private UUID id;

	private String userName;

	private String firstName;

	private String lastName;

	private String email;

	private String password;

	private User() {
		// Default Construtor
	}

	public static User getInstance() {
		if (user == null) {
			user = new User();
		}
		return user;
	}

	public User(String userName, String firstName, String lastName, String email, String password)
			throws InvalidNameException {
		this.id = UUID.randomUUID();
		setUserName(userName);
		setFirstName(firstName);
		setLastName(lastName);
		setEmail(email);
		setPassword(password);
	}

	public void updateUser(User user) {
		this.userName = user.getUserName();
		this.firstName = user.getFirstName();
		this.lastName = user.getLastName();
		this.email = user.getEmail();
		this.password = user.getPassword();
	}

	public UUID getId() {
		return id;
	}

	public String getUserName() {
		return userName;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public String getEmail() {
		return email;
	}

	public String getPassword() {
		return password;
	}

	public void setId(UUID id) {
		this.id = id;
	}

	public void setUserName(String userName) throws InvalidNameException {
		if (userName == null || userName.isEmpty()) {
			throw new InvalidNameException("User name is mandatory");
		}
		if (userName.length() > 8) {
			throw new InvalidNameException("User name character must not be greater than 8");
		} else {
			this.userName = userName;
		}
	}

	public void setFirstName(String firstName) throws InvalidNameException {
		if (firstName == null || firstName.isEmpty()) {
			throw new InvalidNameException("First name is mandatory");
		}
		if (firstName.length() > 2) {
			throw new InvalidNameException("First name character must not be greater than 2");
		} else {
			this.firstName = firstName;
		}
	}

	public void setLastName(String lastName) throws InvalidNameException {
		if (lastName == null || !lastName.isEmpty() && lastName.length() > 4) {
			throw new InvalidNameException("Last name character must not be greater than 4");
		}
		this.lastName = lastName;
	}

	public void setEmail(String email) throws InvalidNameException {
		if (email == null || email.isEmpty()) {
			throw new InvalidNameException("Please enter a Email");
		}
		if (!Pattern.matches("hapag@gmail.com", email)) {
			throw new InvalidNameException("Please enter a valid Email");
		} else {
			this.email = email;
		}
	}

	public void setPassword(String password) throws InvalidNameException {
		if (password == null || password.isEmpty()) {
			throw new InvalidNameException("Please provide any password");
		}
		if (password.length() > 8) {
			throw new InvalidNameException("Please provide password with 8 characters");
		} else {
			this.password = password;
		}
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", userName=" + userName + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", email=" + email + ", password=" + password + "]";
	}
}
