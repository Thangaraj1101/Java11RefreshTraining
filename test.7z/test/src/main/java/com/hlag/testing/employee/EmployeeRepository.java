package com.hlag.testing.employee;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class EmployeeRepository {

	private List<Employee> listEmployee = new ArrayList<>();

	public static void main(String[] args) {

		EmployeeRepository repo = new EmployeeRepository();

		List<Employee> employees = Arrays.asList(
				new Employee("Alice", 60000, "IT", 30),
				new Employee("Bob", 45000, "HR", 25),
				new Employee("Charlie", 55000, "IT", 35),
				new Employee("David", 30000, "Finance", 40),
				new Employee("Eve", 70000, "IT", 29));

		Map<String, Double> result = repo.filterEmployeeMoreThanFiftyThousand(employees);
		System.out.println(result);

		repo.shouldCheckRangeOfInt();
	}


	public Map<String, Double> filterEmployeeMoreThanFiftyThousand(List<Employee> employees) {
		return employees.stream()
				.filter(e -> e.getSalary() > 50000)
				.collect(Collectors.toMap(Employee::getName, Employee::getSalary));
	}

	public double getSalary(List<Employee> employees) {
		return employees.stream().filter(e -> e.getSalary() > 50000).map(Employee::getSalary).reduce(0.00, Double::sum);
	}

	public void shouldCheckRangeOfInt() {

		List<Integer> integer = IntStream.range(1, 10000000).boxed().collect(Collectors.toList());

		Long inteejkf = integer.stream().mapToLong(e -> (long) e * e).sum();
		System.out.println(inteejkf);
	}

}
