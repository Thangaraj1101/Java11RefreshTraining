package com.hlag.testing.service;

import java.util.List;
import java.util.Optional;

import com.hlag.testing.repo.UserRepository;
import com.hlag.testing.repo.UserRepositoryImpl;
import com.hlag.testing.sample.User;

public class UserSeviceImpl implements UserService {

	private static UserSeviceImpl userServiceImpl;

	private UserRepository userRepository = UserRepositoryImpl.getInstance();
	
	public static UserSeviceImpl getInstance() {
		if (userServiceImpl == null) {
			userServiceImpl = new UserSeviceImpl();
		}
		return userServiceImpl;
	}
	
	private UserSeviceImpl() {
	}

	@Override
	public User addUser(User user) {
		return userRepository.addUser(user);
	}

	@Override
	public Optional<User> getUserById(String id) {
		return userRepository.getUserById(id);
	}

	@Override
	public Optional<List<User>> getUsers() {
		return userRepository.getUsers();
	}

	@Override
	public void deleteUser(String id) {
		userRepository.deleteUser(id);
	}

	@Override
	public User updateUser(String id, User user) {
		return userRepository.updateUser(id, user);
	}

}
