package com.hlag.testing.sample;

import java.util.List;
import java.util.Optional;

import com.hlag.testing.exception.DataNotFoundException;
import com.hlag.testing.service.UserService;
import com.hlag.testing.service.UserSeviceImpl;

public class Main {

	public static void main(String[] args) {

		UserService userService = UserSeviceImpl.getInstance();
		User user = null;
		try {

			// Adding the User
			user = new User("Mini", "Rafgfg", "ju", "hapag@gmail.com", "12345678");
			User addUser = userService.addUser(user);
			if (addUser != null) {
				System.out.println("User Details added ID : " + addUser.getId());
			}

			// List the user details
			Optional<List<User>> listUser = userService.getUsers();
			if (listUser.isPresent()) {
				listUser.get().forEach(User::getPassword);
			}


			// // List User By Id
			// Optional<User> optionalUser = userService.getUserById(user.getId().toString());
			// if (optionalUser.isPresent()) {
			// System.out.println("User By Id : " + optionalUser.get());
			// }

			// Update user
			user.updateUser(new User("Don", "Ra", "jujkk", "hapag@gmail.com", "12345678"));
			User updatedUser = userService.updateUser(addUser.getId().toString(), user);
			System.out.println("Updated User : " + updatedUser);

			// Delete user
			Optional<User> deleteUser = userService.getUserById(addUser.getId().toString());
			if (deleteUser.isPresent()) {
				userService.deleteUser(deleteUser.get().getId().toString());
				System.out.println("User Delted Successfully");
			} else {
				throw new DataNotFoundException("Data Not Found");
			}

		} catch (Exception exception) {
			exception.printStackTrace();
		}
	}

}
