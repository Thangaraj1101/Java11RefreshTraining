package com.hlag.testing.deliveryrepo;

import java.util.List;
import java.util.Optional;

import com.hlag.testing.delivery.Delivery;
import com.hlag.testing.exception.DataNotFoundException;

public interface DeliveryRepository {

	// Save a new delivery
	void save(Delivery delivery);

	// Find a delivery by its ID
	Optional<Delivery> findById(String deliveryId);

	// Get all deliveries
	List<Delivery> findAll();

	// Update an existing delivery
	void update(Delivery delivery);

	// Delete a delivery by its ID
	void deleteById(String deliveryId);

	// Get deliveries that are completed
	List<Delivery> findCompletedDeliveries();

	// Find first fifty thresolds records
	List<Delivery> findFirstFiftyThresolds();

	double calculateTotalRevenue();

	double averageTime() throws DataNotFoundException;

}
