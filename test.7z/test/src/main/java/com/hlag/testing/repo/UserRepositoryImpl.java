package com.hlag.testing.repo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import com.hlag.testing.sample.User;

public class UserRepositoryImpl implements UserRepository {

	private static UserRepositoryImpl userRepositoryImpl;

	private List<User> listUser = new ArrayList<>();

	private UserRepositoryImpl() {
	}

	public static UserRepositoryImpl getInstance() {
		if (userRepositoryImpl == null) {
			userRepositoryImpl = new UserRepositoryImpl();
		}
		return userRepositoryImpl;

	}

	@Override
	public User addUser(User user) {
		return listUser.add(user) ? user : null;
	}

	@Override
	public Optional<User> getUserById(String id) {
		return listUser.stream().filter(e -> e.getId().toString().equals(id)).findFirst();
	}

	@Override
	public Optional<List<User>> getUsers() {
		return listUser.isEmpty() ? Optional.empty() : Optional.of(new ArrayList<>(listUser));
	}

	@Override
	public void deleteUser(String id) {
		listUser.removeIf((u -> u.getId().toString().equals(id)));
	}

	@Override
	public User updateUser(String id, User user) {
		UUID userId = UUID.fromString(id);
		for (User updateUser : listUser) {
			if (updateUser.getId().equals(userId)) {
				listUser.addAll(Arrays.asList(user));
				return user;
			}
		}
		return null;
	}

}
