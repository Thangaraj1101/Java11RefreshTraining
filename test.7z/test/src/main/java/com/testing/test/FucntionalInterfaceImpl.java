package com.testing.test;


@FunctionalInterface
interface FucntionalInterfaceImpl {

	public void checkNumberEvenOrOdd(int number);

}
