package com.testing.test;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class Concrete extends AbstractTest {

	@Override
	public void method1() {
		System.out.println("Method 1 Executed");
	}

	@Override
	public void method8() {
		System.out.println("Method 8 Executed");
	}

	@Override
	public void method9() {
		System.out.println("Method 9 Executed");
	}

	public static void main(String[] args) {

		List<String> list = new ArrayList<>();

		UUID.randomUUID();


	}

	@Override
	void method10() {
		System.out.println("Method 10");

	}

}
