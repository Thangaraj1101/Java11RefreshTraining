package com.testing.test;

@FunctionalInterface
interface Interface5 {

	public int test(int name, int b);

	public default void test2() {
		System.out.println("Hello from test 2");
	}

}
