package com.testing.test;


@FunctionalInterface
interface LambdaExpressionInterface {

	public void greet(String greetingName);

}
