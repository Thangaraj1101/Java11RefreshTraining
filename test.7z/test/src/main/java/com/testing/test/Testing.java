package com.testing.test;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.function.IntPredicate;
import java.util.function.UnaryOperator;
import java.util.stream.Collectors;

public class Testing {

	public static void main(String[] args) {

		LambdaExpressionInterface lambdaExpression = greetingName -> System.out.println("Hello," + greetingName);
		lambdaExpression.greet("Alice");

		FucntionalInterfaceImpl funtionalInterface = number -> {
			if (number % 2 == 0) {
				System.out.println("The given Number is even");
			} else {
				System.out.println("The given Number is Odd");
			}
		};
		funtionalInterface.checkNumberEvenOrOdd(6);
		funtionalInterface.checkNumberEvenOrOdd(6);

		// Number Divisible By 7
		IntPredicate calculateValue = x -> x % 7 == 0;
		System.out.println(calculateValue.test(7));

		Function<String, Integer> function = x -> x.length();
		UnaryOperator<Integer> function2 = x -> x * 2;

		System.out.println("adjfdkjkj" + function.andThen(function2).apply("ADVIK"));

		Map<String, Integer> map = new HashMap<>();
		map.put("A", 10);
		map.put("B", 20);
		map.put("C", 30);
		map.put("D", 40);
		map.forEach((k, v) -> System.out.println("Key : " + k + " " + "Value : " + v));

		List<String> list = Arrays.asList(
				"apple",
				"mango",
				"guava",
				"apple",
				"mango",
				"guava",
				"apple",
				"mango",
				"guava",
				"apple",
				"mango",
				"guava",
				"apple",
				"mango",
				"guava",
				"apple",
				"mango",
				"guava",
				"apple",
				"mango",
				"guava",
				"apple",
				"mango",
				"guava",
				"apple",
				"mango",
				"guava",
				"apple",
				"mango",
				"guava");


		List<String> listUpperCase = list.stream()
				.filter(e -> e.length() > 5)
				.map(String::toUpperCase)
				.collect(Collectors.toList());
		listUpperCase.stream().forEach(System.out::println);
		listUpperCase.forEach(System.out::println);



	}


}
