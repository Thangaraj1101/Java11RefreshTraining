package com.testing.test;

@FunctionalInterface
interface StringComparatorInterface {

	public void compareTwoString(String name1, String name2);

}
