package com.hlag.logisticsystem.service;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

public class Package {

	private static Package pack;
	private final String trackingId;
	private double weight;
	private String destination;
	private String status;
	private List<String> milestones;

	private Package() {
		this.trackingId = "";

	}

	public static Package getInstance() {
		if (pack == null) {
			pack = new Package();
		}
		return pack;
	}

	// public Package(String trackingId, String destination, double weight) {
	// super();
	// this.trackingId = trackingId;
	// this.destination = destination;
	// this.status = "In Transit"; // Initial status
	// this.milestones = new ArrayList<>();
	// setWeight(weight);
	// }

	public String getTrackingID() {
		return trackingId;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		if (weight <= 0) {
			throw new IllegalArgumentException("Weight must be positive");
		}
		this.weight = weight;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<String> getMilestones() {
		return Collections.unmodifiableList(milestones);
	}

	public void setMilestones(List<String> milestones) {
		this.milestones = milestones;
	}

	public void markAsDelivered(String status) {
		if (this.status.equals(status)) {
			throw new IllegalArgumentException("package is in transist stage");
		}
		this.status = "Delivered";
		this.milestones.add("Delivered on" + LocalDate.now());
	}

}
