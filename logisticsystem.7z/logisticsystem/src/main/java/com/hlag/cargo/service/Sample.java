package com.hlag.cargo.service;


public abstract class Sample implements Flyable {

	public void sample() {
		System.out.println("Iron man in this ");
	}

}
