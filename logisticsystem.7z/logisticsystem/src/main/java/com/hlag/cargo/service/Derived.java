package com.hlag.cargo.service;


public class Derived extends Base {

	public Derived() {
	}

	public static void test() {

	}


}
