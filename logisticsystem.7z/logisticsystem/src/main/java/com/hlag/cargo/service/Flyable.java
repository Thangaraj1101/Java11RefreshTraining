package com.hlag.cargo.service;


public interface Flyable {

	public void fly();

	public void fly1();

	public void fly2();

	public void fly3();

}
