package com.hlag.cargo.service;


public class Base {

	int value1 = 30;
	int value2 = 20;


	public Base() {

	}

	public static void test() {

	}

}
