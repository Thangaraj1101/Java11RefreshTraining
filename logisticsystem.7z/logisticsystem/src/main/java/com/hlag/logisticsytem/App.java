package com.hlag.logisticsytem;

import com.hlag.logisticsystem.service.Package;

public class App {

	public static void main(String[] args) {

		Package package1 = Package.getInstance();
		Package package2 = Package.getInstance();
		System.out.println(package1.equals(package2));
		System.out.println(package1.hashCode());
		// System.out.println(package1.hashCode());

		// Cargo Variable Declaration and operators

		// variable declaration

		int cargoWeight1 = 500;
		int cargoWeight2 = 750;
		String flightNumber = "AI202";

		// Arithmetic Operators: Calculate total weight.
		System.out.println("Total Cargo Weight" + cargoWeight1 + cargoWeight2);
		System.out.println("Total Cargo Weight" + (cargoWeight1 <= cargoWeight2));

	}

}
